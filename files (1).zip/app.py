from flask import Flask, render_template, request, redirect, url_for, session, flash
from supabase import create_client, Client
import os
import random
import string
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')

# ─── Supabase Config ───────────────────────────────────────────────────────────
SUPABASE_URL = os.environ.get('SUPABASE_URL', 'https://your-project.supabase.co')
SUPABASE_KEY = os.environ.get('SUPABASE_KEY', 'your-anon-key')
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


# ─── Helpers ───────────────────────────────────────────────────────────────────
def generate_token(length=6):
    """Generate a random uppercase alphanumeric token."""
    chars = string.ascii_uppercase + string.digits
    return ''.join(random.choices(chars, k=length))


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_email'):
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_email'):
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated


# ─── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        role     = request.form.get('role', 'user')

        if not email or not password:
            flash('Email and password are required.', 'danger')
            return redirect(url_for('register'))

        # Check if user already exists
        existing = supabase.table('users').select('id').eq('email', email).execute()
        if existing.data:
            flash('An account with that email already exists.', 'warning')
            return redirect(url_for('register'))

        # Insert new user (plain password stored – hash in production!)
        supabase.table('users').insert({
            'email':    email,
            'password': password,
            'role':     role
        }).execute()

        flash('Account created! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        result = supabase.table('users') \
            .select('*') \
            .eq('email', email) \
            .eq('password', password) \
            .execute()

        if result.data:
            user = result.data[0]
            session['user_email'] = user['email']
            session['user_id']    = user['id']
            session['role']       = user['role']
            flash(f"Welcome back, {user['email']}!", 'success')
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('user_dashboard'))
        else:
            flash('Invalid email or password.', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))


@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def user_dashboard():
    user_id = session['user_id']

    if request.method == 'POST':
        subject     = request.form.get('subject', '').strip()
        description = request.form.get('description', '').strip()

        if not subject or not description:
            flash('Subject and description are required.', 'danger')
            return redirect(url_for('user_dashboard'))

        token = generate_token()
        # Ensure uniqueness
        while supabase.table('applications').select('id').eq('token', token).execute().data:
            token = generate_token()

        supabase.table('applications').insert({
            'user_id':     user_id,
            'email':       session['user_email'],
            'subject':     subject,
            'description': description,
            'token':       token,
            'status':      'Waiting'
        }).execute()

        flash(f'Application submitted! Your token is <strong>{token}</strong>.', 'success')
        return redirect(url_for('user_dashboard'))

    apps = supabase.table('applications') \
        .select('*') \
        .eq('user_id', user_id) \
        .order('created_at', desc=True) \
        .execute()

    return render_template('dashboard.html', applications=apps.data)


@app.route('/admin', methods=['GET', 'POST'])
@admin_required
def admin_dashboard():
    if request.method == 'POST':
        doc_id = request.form.get('doc_id')
        status = request.form.get('status')

        if doc_id and status in ('Waiting', 'Processing', 'Completed'):
            supabase.table('applications') \
                .update({'status': status}) \
                .eq('id', doc_id) \
                .execute()
            flash('Status updated successfully.', 'success')
        else:
            flash('Invalid update request.', 'danger')

        return redirect(url_for('admin_dashboard'))

    apps = supabase.table('applications') \
        .select('*') \
        .order('created_at', desc=True) \
        .execute()

    return render_template('admin.html', applications=apps.data)


@app.route('/queue')
def queue_status():
    try:
        apps = supabase.table('applications') \
            .select('*') \
            .in_('status', ['Waiting', 'Processing']) \
            .order('created_at') \
            .execute()
        return render_template('queue.html', applications=apps.data, error=None)
    except Exception as e:
        return render_template('queue.html', applications=[], error=str(e))


# ─── Run ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app.run(debug=True)
